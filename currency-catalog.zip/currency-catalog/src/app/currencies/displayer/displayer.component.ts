import { Component, OnInit, VERSION, ViewChild} from '@angular/core';
import {AfterContentInit} from '@angular/core';
import {MatButtonModule, MatGridList, MatPaginator, MatSort} from '@angular/material';
import { MediaChange, ObservableMedia } from '@angular/flex-layout';
import {startWith, map} from 'rxjs/operators';
import {CurrenciesService} from '../currencies.service';
import {Router} from '@angular/router';
import { ActivatedRoute } from '@angular/router';
import {PageEvent} from '@angular/material';
import {CurrencyAttribute} from '../../models/currencyAttribute';

export interface StateGroup {
  letter: string;
  names: string[];
}
@Component({
  selector: 'app-displayer',
  templateUrl: './displayer.component.html',
  styleUrls: ['./displayer.component.css'],
  providers: [CurrenciesService]

})


export class DisplayerComponent implements OnInit, AfterContentInit {
  @ViewChild('grid') grid: MatGridList;
  @ViewChild(MatPaginator) paginator: MatPaginator;
  @ViewChild(MatSort) sort: MatSort;

  currenciesList = [];
  gridByBreakpoint = {
    xl: 8,
    lg: 6,
    md: 4,
    sm: 2,
    xs: 2
  }
  constructor(private observableMedia: ObservableMedia , private currenciesService: CurrenciesService,private route: ActivatedRoute) {

  }

  currencies = [
    {value: 'id', viewValue: 'Id'},
    {value: 'code', viewValue: 'Code'},
    {value: 'name', viewValue: 'Name'},
    {value: 'type', viewValue: 'Type'}
  ];

  currencyAttribute = new CurrencyAttribute();
  filterBy(filter: string) {
switch (filter) {
  case 'id':
    console.log('filtrer par id');
    break;

case 'code':
  this.currenciesList = this.currenciesList.filter(currency => {
    return currency.title.toLowerCase().includes('qui est esse');
  });
}
}
  ngOnInit() {
this.getData();
  }


  ngAfterContentInit() {
    this.observableMedia.asObservable().subscribe((change: MediaChange) => {
      this.grid.cols = this.gridByBreakpoint[change.mqAlias];
    });
  }
public getData() {
  this.currenciesService.getdata(1).subscribe(resData => this.currenciesList = resData);
}

}

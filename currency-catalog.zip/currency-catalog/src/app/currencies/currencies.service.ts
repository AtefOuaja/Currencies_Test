import { Injectable } from '@angular/core';

import { HttpClient, HttpParams, HttpHeaders } from '@angular/common/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import { Observable} from 'rxjs/Observable';
import {Subject} from 'rxjs/Subject';

@Injectable()
export class CurrenciesService {
  private BASE_URL: string = 'https://jsonplaceholder.typicode.com/posts';
  private BASE_URL1: string = '/assets/json/currencies.json';
  constructor(private http: HttpClient) { }


  public getdata(curId: Number): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/vnd.api+json'
      }),
    };
    return this.http.get(this.BASE_URL, httpOptions);
  }
}
